[CmdletBinding()]
param (
    # Schalter, den du mit `--sync` aufrufst
    [switch]$sync,

    # Pfad zu einer Konfigurationsdatei, z. B. `--config C:\my.cfg`
    [string]$config
)

# ------------------------------------------------------------
# Hilfsfunktion: kurze Usage‑Anzeige, falls nichts übergeben wurde
function Show-Help {
    Write-Host @"
Call:  .\dfir-installer.ps1 [--sync] [--config <Configname>]

Optionen:
  --sync                  Syncs Files form DFIR-Installer-Files Repository
  --config <Configname>   Which configuration to use   
"@
}

#
# STATIC GLOBAL VARS
#
# The configuration for installation directories.
$Desktop_Links_Source_folder = ".\Links\Desktop"
$CURRENTDATETIME = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$LOGFILE2 = "C:\DFIR\DFIR-Install-NonDebug-LogFileInstallLogs_$CURRENTDATETIME.txt"

$noInstallCheckPackages_Winget = @(
    "Microsoft.WSL"
)

$noInstallCheckPackages_Choco = @(
    ""
)

$noInstallCheckPackages_Manual = @(
    "DeepSound"
)

$INSTALL_DIRECTORY = "C:\DFIR\"
$TEMP_DIRECTORY = "C:\DFIR\_tmp"
# The folder in which shortcuts are stored.The configuration for installation directories
$LNK_FOLDER = "C:\DFIR\_Tools\"

# Timer used for manual MSI installations.
$MAN_INSTALL_MSI_TIMER = 10

# The path to the flag file indicating setup has run.
$FLAG_PATH = "C:\DFIR\DFIR-Installer.flag"

# Pfade zu den Konfigurationsordnern
$configDir = "Configs"
$installerConfigDir = "Installer-Configs"
 # Lade die ausgewählte Konfigurationsdatei
$configFile = Join-Path $configDir "$config.conf"

# Path Var Config
$pathvarconfig = "path-var.conf"

#Post Instrallation Scripot Folder
$pp_script_folder = "Post-install-scripts"

# Sync Repository for DFIR-Installer-Files
$global:ZipUrl = 'https://github.com/n0raitor/dfir-installer-files/archive/refs/heads/main.zip'


###############################
### Functions #################
###############################

# ------------------------------------------------------------
# Core sync routine (no external parameters)
function Sync-FromZip {
    param()

    # Download the ZIP file to a temporary location
    $tempZip = Join-Path $env:TEMP ("repo_{0}.zip" -f ([guid]::NewGuid()))
    Write-Host "Downloading archive from $global:ZipUrl ..." -ForegroundColor Cyan
    try {
        Invoke-WebRequest -Uri $global:ZipUrl -OutFile $tempZip -ErrorAction Stop | Out-Null
    } catch {
        Write-Error "Failed to download the archive – $_"
        return
    }

    # Extract the ZIP to a temporary folder
    $extractDir = Join-Path $env:TEMP ("repoExtract_{0}" -f ([guid]::NewGuid()))
    New-Item -ItemType Directory -Path $extractDir | Out-Null
    Write-Host "Extracting archive…" -ForegroundColor Cyan
    try {
        Expand-Archive -LiteralPath $tempZip -DestinationPath $extractDir -Force
    } catch {
        Write-Error "Failed to extract the archive – $_"
        Remove-Item $tempZip -Force
        return
    }

    # GitHub ZIPs wrap everything in a single top‑level folder
    $topLevel = Get-ChildItem -Path $extractDir -Directory | Select-Object -First 1
    if (-not $topLevel) {
        Write-Error "Unexpected archive layout – could not locate top‑level folder."
        Remove-Item $tempZip,$extractDir -Recurse -Force
        return
    }

    # Dynamically discover all first‑level folders in the repo
    $repoRootFolders = Get-ChildItem -Path $topLevel.FullName -Directory |
        Select-Object -ExpandProperty Name

    if (-not $repoRootFolders) {
        Write-Warning "The archive does not contain any top‑level folders to sync."
        Remove-Item $tempZip,$extractDir -Recurse -Force
        return
    }

    Write-Host "Detected repository folders: $($repoRootFolders -join ', ')" -ForegroundColor Green

    # Ensure each detected folder exists locally (create if missing)
    foreach ($folder in $repoRootFolders) {
        $localFolderPath = Join-Path (Get-Location).Path $folder
        if (-not (Test-Path $localFolderPath)) {
            Write-Verbose "Creating missing local folder: $localFolderPath"
            New-Item -ItemType Directory -Path $localFolderPath -Force | Out-Null
        }
    }

    # Copy every file from the extracted archive into the matching local folder,
    # preserving the relative path.
    foreach ($folder in $repoRootFolders) {
        $sourceRoot = Join-Path $topLevel.FullName $folder

        Get-ChildItem -Path $sourceRoot -Recurse -File | ForEach-Object {
            # Relative path inside the current top‑level folder
            $relative = $_.FullName.Substring($sourceRoot.Length).TrimStart('\','/')

            # Destination path under the current working directory
            $dest = Join-Path (Get-Location).Path (Join-Path $folder $relative)

            # Make sure any intermediate sub‑folders exist
            $destDir = Split-Path $dest -Parent
            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }

            # Overwrite the local file with the version from the ZIP
            Copy-Item -Path $_.FullName -Destination $dest -Force
            Write-Verbose "Synced: $folder\$relative"
        }
    }

    # Clean up temporary artefacts
    Remove-Item $tempZip,$extractDir -Recurse -Force
    Write-Host "`nSync complete – only files present in the DFIR-Installer-Files repository were overwritten." -ForegroundColor Yellow
}

# Funktion zur Abfrage der Benutzereingabe
function AskForUpdate {
    param (
        [string]$config
    )
    if ($config -eq "test") {
        Write-Host "Automatisch mit 'Nein' beantwortet, da $config gleich 'test' ist."
        return $false
    }
    
    $response = Read-Host "Möchten Sie die Pakete aktualisieren? (y/n)"
    
    switch ($response.ToLower()) {
        "y" {
            Write-Host "Update wird durchgeführt..."
            return $true
        }
        "n" {
            Write-Host "Kein Update durchgeführt."
            return $false
        }
        default {
            Write-Host "Ungültige Eingabe, bitte 'y' für Ja oder 'n' für Nein eingeben."
            return AskForUpdate  # Rekursiver Aufruf bei ungültiger Eingabe
        }
    }
}
function Install-Program-From-Msi {
    param (
        [string]$ProgramName,  # The name of the program to display in logs
        [string]$MsiPath,       # The full path to the MSI file
        [string]$installfolder = $null # folder to install the program
    )

    # Check if the MSI file exists
    if (-Not (Test-Path -Path $MsiPath)) {
        Write-Error "The MSI file does not exist at the specified path: $MsiPath"
        return
    }

    # Build the msiexec command
    $msiexecCommand = $MsiPath

    # Print out the full command in debug mode before executing it
    Write-Debug "Executing command: $msiexecCommand"

    if ($null -ne $installfolder -and $installfolder -ne "") {
        Write-Host "installfolder is set: $installfolder"
        try {
            Write-Debug "Execute: msiexec.exe /i $MsiPath INSTALLDIR=$installfolder /norestart "
            #msiexec.exe /i $MsiPath /norestart 
            $process = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$MsiPath`" /norestart" -Wait -NoNewWindow
            
            #msiexec /i "$MsiPath" INSTALLDIR="$installfolder" /qn /norestart /log install.log
            #Write-Debug "Execute: Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$msiPath`" INSTALLDIR=`"$installDir`" /qn /norestart" -Wait -NoNewWindow"
            #$process = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i `"$msiPath`" INSTALLDIR=`"$installDir`" /qn /norestart" -Wait -NoNewWindow

            # Wait for the installer to finish (this will be the GUI-based installer now)
            #$process.WaitForExit()
            
            Write-Host "     [Installer Spawned: $ProgramName]" -ForegroundColor DarkGreen
            #Start-Sleep -Seconds 30
            $process.WaitForExit()


            # Print [OK] once the installation completes
            #Write-Host "     [Installer Spawned: $ProgramName]" -ForegroundColor DarkGreen
            #Start-Sleep -Seconds 30
            #$process.WaitForExit()
        }
        catch {
            Write-Debug "An error occurred while installing $ProgramName : $_" 
        }
    } else {
        Write-Host "installfolder is not set."
        try {
            Write-Debug "$ProgramName : $MsiPath"
            
            # Start the installer with msiexec (without /quiet or /norestart)
            $process = Start-Process -FilePath $MsiPath -Wait -PassThru
            
            # Wait for the installer to finish (this will be the GUI-based installer now)

            # Print [OK] once the installation completes
            Write-Host "     [Installer Spawned: $ProgramName]" -ForegroundColor DarkGreen
            #Start-Sleep -Seconds 30
            $process.WaitForExit()

        }
        catch {
            Write-Debug "An error occurred while installing $ProgramName : $_" 
        }
    }

    # Try to start the installer and wait for it to complete
    
}
function Install-Program-From-Exe {
    param (
        [string]$ProgramName,  # The name of the program to display in logs
        [string]$ExePath,       # The full path to the executable file
        [string]$installfolder = $null # folder to install the program
    )

    # Check if the executable exists
    if (-Not (Test-Path -Path $ExePath)) {
        Write-Error "The executable file does not exist at the specified path: $ExePath" 
        return
    }

    # Try to start the installer and wait for it to complete
    try {
        Write-Debug "$ProgramName : $ExePath"
        
        # Start the installer in the background and capture the process
        $process = Start-Process -FilePath $ExePath -Wait -PassThru
        # Wait for the installer to finish

        # Print [OK] once the installation completes
        Write-Host "     [Installer Spawned: $ProgramName]" -ForegroundColor DarkGreen
        $process.WaitForExit()
        # Start-Sleep -Seconds 30
    }
    catch {
        Write-Debug "An error occurred while installing $ProgramName : $_" 
    }
}
function Download-And-Extract {
    param (
        [string]$url,         # URL to download from
        [string]$destination, # Destination folder
        [string]$runFile,      # Optional file to run after extraction (relative path within extracted folder)
        [string]$installfolder = $null # folder to install the program
    )
    
    # Create the destination folder if it doesn't exist
    Write-Debug "$url -> $destination -> $runFile"
    if (-not (Test-Path -Path $destination)) {
        if ($PSDebugPreference -eq 'Continue') {
            New-Item -Path $destination -ItemType Directory
            Write-Debug "Creating destination directory: $destination"
        } else {
            New-Item -Path $destination -ItemType Directory *>> $LOGFILE2
        }
        
    }

    # Download the file
    $fileName = [System.IO.Path]::GetFileName($url)
    $filePath = Join-Path -Path $destination -ChildPath $fileName
    Write-Debug "Downloading file from $url to $filePath..."
    $validNames = @("KAPE.zip", "NirSoft-Everything.zip", "ArtiFast.zip", "VMware-workstation-full-17.6.1-24319023.exe", "binaryninja_free_win64.exe", "metasploitframework-latest.msi")
	if ($validNames -contains $fileName) {
		Start-BitsTransfer -Source $url -Destination $filePath
	} else {
		try {
            Invoke-WebRequest -Uri $url -OutFile $filePath -UseBasicParsing
        } catch {
            Write-Error "Download failed for $url : $($_.Exception.Message)"
        }
	}


    # Extract the file if it's a ZIP or 7z file
    if ($fileName.EndsWith(".zip")) {
        Write-Host "     [Extracting: $fileName]" -ForegroundColor DarkGreen
        if ($PSDebugPreference -eq 'Continue') {
            Write-Debug "Extracting ZIP file..."
            & 'C:\Program Files\7-Zip\7z.exe' x $filePath "-o$destination" -y
            Remove-Item $filePath -Force
        } else {
            & 'C:\Program Files\7-Zip\7z.exe' x $filePath "-o$destination" -y *>> $LOGFILE2
            Remove-Item $filePath -Force *>> $LOGFILE2
        }
    } elseif ($fileName.EndsWith(".7z")) {
        Write-Host "     [Extracting: $fileName]" -ForegroundColor DarkGreen
        if ($PSDebugPreference -eq 'Continue') {
            Write-Debug "Extracting 7z file..."
            # Assuming 7zip is installed and its path is available in the system's PATH environment variable
            if ($filePath -match "merlin") {
            & 'C:\Program Files\7-Zip\7z.exe' x $filePath "-o$destination" -pmerlin -y
            } else {
                & 'C:\Program Files\7-Zip\7z.exe' x $filePath "-o$destination" -y
            }
            Remove-Item $filePath -Force
            if ($filePath -match "merlin") {
                & 'C:\Program Files\7-Zip\7z.exe' x $filePath "-o$destination" -pmerlin -y *>> $LOGFILE2
            } else {
                & 'C:\Program Files\7-Zip\7z.exe' x $filePath "-o$destination" -y *>> $LOGFILE2
            }
            Remove-Item $filePath -Force *>> $LOGFILE2
        }
        #Delete Archive        
    } elseif ($fileName.EndsWith(".tgz") -or $fileName.EndsWith(".tar.gz")) {
        Write-Host "     [Extracting: $fileName]" -ForegroundColor DarkGreen
        if ($PSDebugPreference -eq 'Continue') {
            Write-Debug "Extracting TGZ or TAR.GZ file..."
            # Assuming tar is available in the system
            tar -xzf $filePath -C $destination
            #Delete Archive
            Remove-Item $filePath -Force
        } else {
            # Assuming tar is available in the system
            tar -xzf $filePath -C $destination *>> $LOGFILE2
            #Delete Archive
            Remove-Item $filePath -Force *>> $LOGFILE2
        }    
    } else {
        Write-Debug "No extraction needed for file type: $fileName"
    }

    Write-Debug "$runFile"
    

    # If a runFile was provided, try to run it
    if ($runFile) {
        Write-Host "     [Run File: $runFile]" -ForegroundColor DarkGreen
        $runFilePath = Join-Path -Path $destination -ChildPath $runFile
        if (Test-Path $runFilePath) {
            Write-Debug "Running $runFilePath..."
            #& $runFilePath
            Write-Debug "Manuelle Installation mit Befehl: $runFilePath"
            if ($runFilePath.EndsWith(".msi"))
            {   
                Write-Debug "Installing: $runFilePath"
                #Start-Process "$_" | Out-Null
                #Start-Sleep $MAN_INSTALL_MSI_TIMER
                #Install-Program-From-Msi -ProgramName " [Manual Install MSI]" -MsiPath "$runFilePath"  
                Install-Program-From-Msi -ProgramName "$runFile" -MsiPath "$runFilePath" -installfolder $installfolder    #".\Binaries\wsl_update_x64.msi"
            }
            else {
                Write-Debug "Installing: $runFilePath"
                #& "$_" | Out-Null
                #Write-Host "INSTALLED"
                #Install-Program-From-Exe -ProgramName " [Manual Install]" -ExePath "$runFilePath" 
                Install-Program-From-Exe -ProgramName "$runFile" -ExePath "$runFilePath" -installfolder $installfolder
            }      
        } else {
            #Write-Host "The file to run '$runFile' does not exist in the extracted folder."
            Write-Debug "Running $runFilePath..."
            & $runFilePath
        }
    }
}
function Process-GitHub-ConfigFile {
    param (
        [string]$configFilePath
    )

    # Read each line from the config file
    $lines = Get-Content -Path $configFilePath

    foreach ($line in $lines) {

        if ($line.Trim().StartsWith("#")) {
            #Write-Host "Skipping comment line: $repo"
            continue
        }
        # Split the line by space to get URL, Destination, and optional runFile
        $parts = $line -split '\s+'
        $packageName = $parts[0]
        $url = $packageName

        if ($url -match "/([^/]+)/archive") {
            $url = $matches[1]
        }

        

        
        if ($parts.Length -ge 2) {
            $url = $parts[0]
            $destination = $parts[1]
            $runFile = if ($parts.Length -gt 2) { $parts[2] } else { $null }
            Write-Debug "url: $url, destination: $destination, runFile: $runFile"
            # Call Download-And-Extract with the parameters
            Download-And-Extract -url $url -destination $destination -runFile $runFile
        } else {
            Write-Debug "Invalid line in config file: $line"
        }
    }
}
function Install-FromConfigFile {
    param (
        [string]$configFilePath,    # Path to the configuration file containing repo details
        [string]$parentFolder       # Parent folder to save the release
    )

    # Check if the configuration file exists
    if (-not (Test-Path $configFilePath)) {
        Write-Host "Configuration file not found at $configFilePath"
        return
    }

    # Read the content of the config file
    $repos = Get-Content -Path $configFilePath

    # Iterate over each line in the configuration file
    foreach ($repo in $repos) {
        # Skip lines that start with "#" (comment lines)
        if ($repo.Trim().StartsWith("#")) {
            #Write-Host "Skipping comment line: $repo"
            continue
        }

        # Split the line into parts (repo and optional script)
        $repoParts = $repo.Split(" ")

        # Validate repo format
        if ($repoParts.Length -ge 1) {
            $repoDetails = $repoParts[0].Split("/")
            if ($repoDetails.Length -eq 2) {
                $githubRepoOwner = $repoDetails[0]
                $githubRepoName = $repoDetails[1]

                # Check if an install script was provided
                $installScriptName = if ($repoParts.Length -gt 1) { $repoParts[1] } else { $null }

                Write-Host "Processing $githubRepoOwner/$githubRepoName"

                # Call the Install-GitHubRelease function to install the release
                Install-GitHubRelease -githubRepoOwner $githubRepoOwner -githubRepoName $githubRepoName -installScriptName $installScriptName -parentFolder $parentFolder
            } else {
                Write-Host "Invalid entry in config file: $repo. Skipping..."
            }
        } else {
            Write-Host "Invalid entry in config file: $repo. Skipping..."
        }
    }
}
function init-setup {
    param (
        [string]$Usern,
        [string]$config
    )
    New-Item -Path "c:\" -Name "DFIR" -ItemType "directory"
    New-Item -Path "c:\DFIR" -Name "_Tools" -ItemType "directory"
    #New-Item -Path "c:\DFIR" -Name "_GitHub" -ItemType "directory"
    New-Item -ItemType SymbolicLink -Force -Path "C:\Users\$Usern\Desktop\Tools" -Target "C:\DFIR\_Tools" 
    #New-Item -ItemType SymbolicLink -Force -Path "C:\DFIR\_Tools\_GitHub" -Target "C:\DFIR\_GitHub"
    New-Item -ItemType SymbolicLink -Force -Path "C:\DFIR\_Tools\_DFIR" -Target "C:\DFIR" 
    New-Item -ItemType SymbolicLink -Force -Path "C:\DFIR\_Tools\_choco-bin" -Target "C:\ProgramData\chocolatey\bin"
    New-Item -ItemType SymbolicLink -Force -Path "C:\DFIR\_Tools\_choco-lib" -Target "C:\ProgramData\chocolatey\lib"
       
    # Write $Usern and $config to the flag file, each on its own line
    "$Usern`n$config" | Set-Content -Path $FLAG_PATH -Force

    Write-Host ""
}
function post-processing {
    param (
        [string]$Usern
    )

    $dirs = "C:\DFIR\_Tools\"
    $currentUserPath = [Environment]::GetEnvironmentVariable("PATH", [System.EnvironmentVariableTarget]::User)
    $newPath = $currentUserPath + ";" + ($dirs -join ";")
    [Environment]::SetEnvironmentVariable("PATH", $newPath, [System.EnvironmentVariableTarget]::User)

    $Desktop_Pfad = [System.Environment]::GetFolderPath("Desktop")
    $Ziel_Pfad = "C:\Users\$Usern\Desktop\Tools"
    Write-Output $Desktop_Pfad
    Write-Output $Ziel_Pfad
    Write-Output $(Get-ChildItem -Path $Desktop_Pfad -Filter *.lnk)
    Get-ChildItem -Path $Desktop_Pfad -Filter *.lnk | Move-Item -Destination $Ziel_Pfad
    Get-ChildItem -Path $Desktop_Pfad -Filter *.LNK | Move-Item -Destination $Ziel_Pfad
    Get-ChildItem -Path $Desktop_Pfad -Filter *.exe | Move-Item -Destination $Ziel_Pfad
    Get-ChildItem -Path $Desktop_Pfad -Filter *.EXE | Move-Item -Destination $Ziel_Pfad
        # Definiere den Desktop-Pfad und den Zielordner
    $desktopPath = [System.Environment]::GetFolderPath('Desktop')
    $targetFolder = "C:\DFIR\_Tools"

    # Überprüfen, ob der Zielordner existiert, andernfalls erstellen
    if (-not (Test-Path $targetFolder)) {
        New-Item -Path $targetFolder -ItemType Directory
        Write-Host "Target folder created: $targetFolder"
    }

    # Hole alle Dateien auf dem Desktop (ohne Unterordner), außer .txt-Dateien
    $files = Get-ChildItem -Path $desktopPath -File | Where-Object { $_.Extension -ne '.txt' }

    # Verschiebe jede Datei in den Zielordner
    foreach ($file in $files) {
        $destinationPath = Join-Path -Path $targetFolder -ChildPath $file.Name
        Move-Item -Path $file.FullName -Destination $destinationPath -Force
        Write-Host "File Moved: $($file.Name)"
    }
    Write-Host "--- Moved all Desktop Icons to Tools Folder on the Desktop ---"



    # Copy update script to desktop
    $currentDir = Get-Location
    $sourceFile = "$currentDir\update-system.ps1"
    Copy-Item -Path $sourceFile -Destination $Desktop_Pfad
    Write-Host "--- Copied update script to desktop ---"

    
    # Copy every Link from the Links\Desktop folder to the current user's desktop
    if (Test-Path $Desktop_Links_Source_folder) {
        # Copy all files and directories (recursively) to the desktop
        Copy-Item -Path "$Desktop_Links_Source_folder\*" -Destination $Desktop_Pfad -Recurse -Force
        Write-Host "--- Copied Custom Links to the desktop ---"
    } else {
        Write-Host "Source path '$Desktop_Links_Source_folder' does not exist."
    }

    # Enable detailed context menu
    reg.exe add "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" /f /ve
    Write-Host "--- Enable Detailed Context Menu ---"


    $targetPath = "C:\Users\$Usern\AppData\Local\Microsoft\WinGet\Links"
    $linkPath = "C:\DFIR\_Tools\_winget-packages"

    if (Test-Path -Path $targetPath) {
        if (-not (Test-Path -Path $linkPath)) {
            New-Item -ItemType SymbolicLink -Force -Path $linkPath -Target $targetPath
            Write-Host "Symbolic link created."
        } else {
            Write-Host "Link path already exists: $linkPath"
        }
    } else {
        Write-Host "Target path does not exist: $targetPath"
    }
    Write-Host "--- Created Winget Link in Tools Folder ---"


    # ### Create Powershell Admin Prompt LNK
    # # Define the directory and shortcut name
    # $ShortcutPath = [System.IO.Path]::Combine([System.Environment]::GetFolderPath("Desktop"), "PowerShell Admin Prompt")
    # # Create a new WScript.Shell COM object
    # $WScriptShell = New-Object -ComObject WScript.Shell
    # # Create a shortcut object
    # $Shortcut = $WScriptShell.CreateShortcut($ShortcutPath)
    # # Set the target path to the PowerShell executable
    # $Shortcut.TargetPath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    # # Set the arguments to start PowerShell as an administrator
    # $Shortcut.Arguments = ""
    # # Set the working directory
    # $Shortcut.WorkingDirectory = "C:\Windows\System32\WindowsPowerShell\v1.0"
    # # Set the window style (1 for normal window)
    # $Shortcut.WindowStyle = 1
    # # Set a description for the shortcut
    # $Shortcut.Description = "PowerShell Admin Prompt"
    # # Optionally, set an icon for the shortcut
    # $Shortcut.IconLocation = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    # # Save the shortcut
    # $Shortcut.Save()
    # Write-Host "PS Admin Prompt Shortcut Created"
}
function copy-documents {
    param (
        [string]$Usern
    )
    Write-Host ""
    Write-Host "######## Copy Documents and Templates ########" -ForegroundColor Green
    Write-Host ""
    $cpy_documents_location = ".\Documents\"

    # Definiere den Zielpfad mit der Benutzer-Variable
    $destinationPath = "C:\Users\$Usern\Documents"

    # Stelle sicher, dass der Zielordner existiert
    if (-Not (Test-Path -Path $destinationPath)) {
        Write-Host "Target folder does not exist: $destinationPath"
        Write-Host "Skipping..."
    } else {
        # Erhalte alle Ordner im Quellverzeichnis
        $folders = Get-ChildItem -Path $cpy_documents_location -Directory
        Write-Debug "Copy $folders"

        # Verschiebe jeden Ordner in das Zielverzeichnis
        foreach ($folder in $folders) {
            Write-Debug "Folder: $folder"
            $sourceFolderPath = $folder.FullName
            $destinationFolderPath = Join-Path -Path $destinationPath -ChildPath $folder.Name
            
            try {
                Copy-Item -Path $sourceFolderPath -Destination $destinationFolderPath -Recurse -Force
                Write-Host "Sucessfully Moved Folder: $($folder.Name)"
            } catch {
                Write-Host "Error during Folder Move: $($folder.Name) - $($_.Exception.Message)" -ForegroundColor Red
            }
        }
    }
    Write-Host ""
    Write-Host "######## Finished Copying Documents and Templates ########" -ForegroundColor Green
    Write-Host ""
}
function post-install-fixes {

    $packageName =  "Post Installation Fixes"

    ##### Updating Script
    if ($config -ne "Testing") {
        $packageName =  "Updating Packages"
        .\update-system.ps1
    }
}
function install-winget {
    param (
        [string]$command,
        [string]$toolname
    )
    Write-Host "----- Installing $toolname -----" -ForegroundColor Green
    
    Write-Host "Winget Output Started" -ForegroundColor DarkGreen
    winget install --id $command --silent --accept-package-agreements
    Write-Host "Winget Output Ended" -ForegroundColor DarkGreen
    Write-Host ""
    $installed = winget list | Select-String -SimpleMatch $command
    $shortname = ($command -split '\.')[-1]
    $installed_short = winget list | Select-String -SimpleMatch $shortname
    
    if ($installed) {
        Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
    } elseif ($installed_short) {
        Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
    } elseif ((Test-Path "C:\cygwin64") -and ($command -eq "Cygwin.Cygwin")) {
        # Special case for Cygwin, as winget lists it as "Cygwin.Cygwin" but it installs to C:\cygwin64
        Write-Debug "     [Cygwin64 detected at C:\cygwin64]" 
        Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
    } elseif ($noInstallCheckPackages_Winget -contains $command) {
        Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
        Write-Debug "Special package $command, skipping installation check."
    } else {
        Write-Host "     [Installation FAILED: $toolname]" -ForegroundColor DarkRed
        Write-Debug "CHeck result $installed"
        Write-Debug "winget list | Select-String -SimpleMatch $command"
    }
    
    #winget install --id $command --silent --accept-package-agreements
    # --ignore-security-hash (If the hash is not correct)
    # Füge hier den Winget Installationsbefehl ein
}
function install-choco {
    param (
        [string]$command,
        [string]$toolname
    )
    Write-Host "----- Installing $toolname -----" -ForegroundColor Green

    # Run choco install, logging output to $LOGFILE2 if not debugging
    Write-Debug "Führe aus: choco install $command -y --ignore-checksums"
    Write-Host "Chocolatey Output Started" -ForegroundColor DarkGreen
    choco install $command -y --ignore-checksums
    Write-Host "Chocolatey Output Ended" -ForegroundColor DarkGreen
    Write-Host ""
    # Check if package installed by querying choco list
    $installed = choco list | Select-String -SimpleMatch $command
    if ($installed) {
        Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
    } elseif ($noInstallCheckPackages_Choco -contains $command) {
        Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
        Write-Debug "Special package $command, skipping installation check."
    } else {
        Write-Host "     [Installation FAILED: $toolname]" -ForegroundColor DarkRed
        Write-Debug "CHeck result $installed"
        Write-Debug "choco list | Select-String -SimpleMatch $command"
    }

    # Füge hier den Choco Installationsbefehl ein
}

#DEPRECATED
function install-copy {
    param (
        [string]$command,
        [string]$toolname
    )
    Write-Host "Copy File with command: $command"
    
    $Inputstring = $command
    $CharArray = $InputString.Split(" ")
    $Path_To_Portable = $CharArray[0]
    $Path_To_EXE = $CharArray[1]
    $Name_of_LNK = $CharArray[2]
    Write-Host "Installing: $Path_To_EXE"
    Write-Host "Path: $Path_To_Portable"
    Write-Host "LNK-NAME: $Name_of_LNK"
    $Copy_Path = $INSTALL_DIRECTORY + $Name_of_LNK
    Write-Output $Path_To_Portable
    Write-Output $Copy_Path
    Copy-Item -Path $Path_To_Portable -Destination $Copy_Path -Recurse
    #& "$_" | Out-Null
    $LNK_IN = $INSTALL_DIRECTORY + $Name_of_LNK + "\" + $Path_To_EXE
    $LNK_OUT = $LNK_FOLDER + $Name_of_LNK      # + ""
    New-Item -ItemType SymbolicLink -Force -Path $LNK_OUT -Target $LNK_IN
    Write-Host "INSTALLED"
}


function install-manual {
    param (
        [string]$command,
        [string]$toolname
    )
   <#  Write-Host "Manuelle Installation mit Befehl: $command"
    if ($command.EndsWith(".msi"))
    {   
        Write-Host "Installing: $command"
        #Start-Process "$_" | Out-Null
        #Start-Sleep $MAN_INSTALL_MSI_TIMER
        Install-Program-From-Msi -ProgramName "Manual Install MSI" -MsiPath "$command"       #".\Binaries\wsl_update_x64.msi"
    }
    else {
        Write-Host "Installing: $command"
        #& "$_" | Out-Null
        #Write-Host "INSTALLED"
        Install-Program-From-Exe -ProgramName "Manual Install" -ExePath "$command" 
    }       #>
    $parts = $command -split '\s+'
    $packageName = $parts[0]
    $url = $packageName
    $binary = $parts[1]
    Write-Debug "url: $url, destination: $TEMP_DIRECTORY, runFile: $binary"

    $INSTALL_DIRECTORY = "C:\DFIR\$toolname"
    Write-Host "Please install to: $INSTALL_DIRECTORY"
    # Call Download-And-Extract with the parameters
    Download-And-Extract -url $url -destination $TEMP_DIRECTORY -runFile $binary -installfolder $INSTALL_DIRECTORY

    if (Test-Path $INSTALL_DIRECTORY -PathType Container) {
        $files = Get-ChildItem -Path $INSTALL_DIRECTORY -ErrorAction SilentlyContinue
        if ($files.Count -gt 0) {
            Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
        } else {
            Write-Host "     [Installation FAILED: $toolname]" -ForegroundColor DarkRed
            Write-Debug "Folder exists, but no files found"
        }
    } elseif ($noInstallCheckPackages_Manual -contains $command) {
        Write-Host "     [Installation OK: $toolname ($INSTALL_DIRECTORY)]" -ForegroundColor DarkGreen
        Write-Debug "Special package $command, skipping installation check."
    } else {
        Write-Host "     [Installation FAILED: $toolname (Should be: $INSTALL_DIRECTORY). If you choosed another location, ignore this error!]" -ForegroundColor DarkRed
        Write-Debug "Folder does not exist"
    }
    # Check if installation was successful

}
function install-github {
    param (
        [string]$command,
        [string]$toolname
    )
    Write-Host "----- Installing $toolname -----" -ForegroundColor Green

    Write-Debug "Github Installation mit Befehl: $command"
    # Split the line by space to get URL, Destination, and optional runFile
    $parts = $command -split '\s+'
    $packageName = $parts[0]
    $url = $packageName

    if ($url -match "/([^/]+)/archive") {
        $url = $matches[1]
    }

    if ($parts.Length -ge 2) {
        $url = $parts[0]
        $destination = $parts[1]
        $runFile = if ($parts.Length -gt 2) { $parts[2] } else { $null }
        Write-Debug "url: $url, destination: $destination, runFile: $runFile"
        # Call Download-And-Extract with the parameters
        Download-And-Extract -url $url -destination $destination -runFile $runFile
        #Write-Host "$destination"

        if (Test-Path $destination -PathType Container) {
            $files = Get-ChildItem -Path $destination -ErrorAction SilentlyContinue
            if ($files.Count -gt 0) {
                Write-Host "     [Installation OK: $toolname]" -ForegroundColor DarkGreen
            } else {
                Write-Host "     [Installation FAILED: $toolname]" -ForegroundColor DarkRed
                Write-Debug "Folder exists, but no files found"
            }
        } else {
            Write-Host "     [Installation FAILED: $toolname]" -ForegroundColor DarkRed
            Write-Debug "Folder does not exist"
        }

    } else {
        Write-Debug "Invalid line in config file: $line"
    }
}
function path-var-config-import {

    # Prüfen, ob die Datei existiert
    if (Test-Path $pathvarconfig) {
        # Aktuelle PATH-Variable holen
        $CurrentPath = [System.Environment]::GetEnvironmentVariable("PATH", "Process")

        # Pfade aus der Datei lesen und hinzufügen
        Get-Content $pathvarconfig | ForEach-Object {
            $NewPath = $_.Trim()
            
            if (!(Test-Path $NewPath)) {
                Write-Debug "Path not found: $NewPath"
            }
            elseif ($CurrentPath -notmatch [regex]::Escape($NewPath)) {
                $CurrentPath += ";$NewPath"
            }
        }

        # PATH für die aktuelle Sitzung setzen
        [System.Environment]::SetEnvironmentVariable("PATH", $CurrentPath, "Process")

        Write-Host "PATH-Variable updated!" -ForegroundColor Green
    } else {
        Write-Host "Configuration file not found: $pathvarconfig" -ForegroundColor Red
    }

    if (!(Test-Path $PROFILE)) { New-Item -ItemType File -Path $PROFILE -Force }
    #notepad $PROFILE  # Öffnet es in Notepad zum Bearbeiten
    [System.Environment]::SetEnvironmentVariable("PATH", $CurrentPath, "User")
}

function Main {
    Write-Host ""
    Write-Host "Welcome to the DFIR-Installer"


    # If --sync was set
    if ($sync.IsPresent) {
        Sync-FromZip       
    }

    #if ($config -eq "") {
    #    exit 0
    #}

    ### Ask if Choco is already installed
    Write-Debug "Make sure that Chocolatey is installed"

    ### Logging ###
    # Define log file path with current date and time
    $logFilePath = ".\DFIR-Install-LogFile_$CURRENTDATETIME.txt"

    # Start logging
    Start-Transcript -Path $logFilePath
    ### Use this For Logging Output of CMDs
    #| Tee-Object -FilePath $logFilePath -Append
    # Message to be displayed on screen
    Write-Debug ""
    Write-Debug "Detailed Logging in file $logFilePath"
    Write-Debug ""
    Write-Host "####################################"
    Write-Host "Starting Installation Phase" -ForegroundColor Green
    Write-Host "####################################"
    Write-Host ""
    ###############################
    # INITIAL SETUP ###############
    ###############################
    # Check if the flag file exists (DFIR-Installer Has Run)
    if (Test-Path $FLAG_PATH) {
        Write-Host "##################################################" 
        Write-Host "Installer has already run. Skipping INIT Setup..." -ForegroundColor Green
        Write-Host "##################################################" 
        Write-Host ""
        try {
            $flagLines = Get-Content -Path $FLAG_PATH
            $previous_usern = $flagLines[0]
            $previous_config = $flagLines[1]
            Write-Host "Previous Config: $previous_config)"
            Write-Host "Previous User: $previous_usern"
            $Usern = $previous_usern
            $configFile = $previous_config
            $config = $([System.IO.Path]::GetFileNameWithoutExtension($configFile))
        } catch {
            Write-Error "Not All Flag Parameter found in $FLAG_PATH. Please delete the file and re-run the script if you want to change the user or config."
            Write-Error "An error occurred: $($_.Exception.Message)"
            exit 1
        }
        
    } else {
        Write-Host "###############################" 
        Write-Host "######## Initial Setup ########" -ForegroundColor Green
        Write-Host "###############################" 
        Write-Host ""
        # Test condition for User Input and Presetup reminder to user
        Sync-FromZip
        if ($config -ne "test" -and $config -ne "test_base") {
            Write-Host ""
            $choco_installed = Read-Host -Prompt "Press [Enter] if you followed every prepare step described in the README.md. Link: https://github.com/n0raitor/dfir-installer/blob/main/README.md"
            $Usern = Read-Host "Enter your username (For Symbolic Links on the Desktop). This should match the folder name in the C:\Users\<Username>\ Directory:"
            Write-Host ""
        } else {
            $Usern = "NormanSchmidt"
        }
        init-setup $Usern $configFile
    }
    
    
    # Test if Configuration file exists
    if (-Not (Test-Path $configFile)) {
        Write-Error "Configuration File: $configFile not found. Please check if your config file is in the Configs folder." 
        exit
    }

    ###############################
    # 7z installer  ###############
    ###############################
    install-winget "7zip.7zip" "7-Zip"

    ###############################
    # INSTALLATION ###############
    ###############################
    # Lese alle Zeilen der Konfigurationsdatei
    $configLines = Get-Content $configFile

    #$currentLocation = (Get-Location).Path
    #if ($currentLocation -ne "C:\DFIR\_dfir-installer" -and -not ($configLines -contains "dfir-installer")) {
    #    $configLines += "dfir-installer"
    #    Write-Host ""
    #    Write-Host "Added dfir-installer to the installation list"
    #    Write-Host ""
    

    # Manual Installer Command will get executed at the end
    $manualInstallCommands = @()
    $manualInstallToolName = @()

    # Gesamtanzahl der Zeilen
    $totalLines = $configLines.Count
    Write-Host ""
    Write-Host "##################################################"
    Write-Host "$totalLines Tools will get installed" -ForegroundColor Green
    Write-Host "##################################################"
    Write-Host ""

    ##################################
    # Tool Installation Section ######
    ##################################

    # Initialisiere den Zähler
    $counter = 0

    # Gehe jede Zeile durch, um den Tool-Namen zu finden
    foreach ($line in $configLines) {
        # Berechne den Fortschritt
        Write-Host "" #Neue Zeile für bessere Lesbarkeit
        
        $toolName = $line.Trim()
        if ([string]::IsNullOrEmpty($toolName)) {
            continue
        }

        # Suche in den Installer-Konfigurationsdateien nach dem Tool-Namen
        $toolFoundFiles = Get-ChildItem -Path $installerConfigDir -Filter "*.conf" | Where-Object {
            (Select-String -Path $_.FullName -Pattern "^$toolName\s*\|" -Quiet)
        }

        # Fortschrittsanzeige aktualisieren
        $percentComplete = ($counter / $totalLines) * 100
        Write-Progress -PercentComplete $percentComplete -Status "[$counter/$totalLines]" -Activity "Installing $toolName"

        if ($toolFoundFiles.Count -eq 1) {
            # Führe die entsprechende Installationsfunktion aus
            $installerConfig = $toolFoundFiles[0]
            $commandLine = (Select-String -Path $installerConfig.FullName -Pattern "^$toolName\s*\|" | ForEach-Object { $_.Line.Trim() }).Split("|")[1].Trim()
            Write-Debug "Installing $toolName with command: $commandLine"
            # Je nach Installer-Konfiguration rufe die passende Funktion auf
            if ($installerConfig.Name -eq "Winget.conf") {
                install-winget $commandLine $toolName
            } elseif ($installerConfig.Name -eq "Choco.conf") {
                install-choco $commandLine $toolName
            } elseif ($installerConfig.Name -eq "Copy.conf") {
                install-copy $commandLine $toolName
            } elseif ($installerConfig.Name -eq "Manual.conf") {
                # Füge den Befehl zur manuellen Installation hinzu
                Write-Host "----- Skipping Installation of $toolname for MANUAL INSTALL later -----" -ForegroundColor Green
                $manualInstallCommands += $commandLine
                $manualInstallToolName += $toolName
            } elseif ($installerConfig.Name -eq "Github.conf") {
                install-github $commandLine $toolName
            }
        } elseif ($toolFoundFiles.Count -eq 0) {
            Write-Error "Kein Tool namens '$toolName' in den Installer-Konfigurationsdateien gefunden."
        } else {
            Write-Error "Mehr als eine Übereinstimmung für Tool '$toolName' gefunden. Bitte überprüfen Sie die Konfigurationsdateien."
        }
        
        # Post Install Script Section
        if ($installerConfig.Name -ne "Manual.conf") {
            # Überprüfen und Ausführen eines Skripts im Ordner "$pp_script_folder"
            $postInstallScriptPath = "$pp_script_folder\$toolName.ps1"
            #Write-Host "Post-Install-Script: $postInstallScriptPath"
            if (Test-Path $postInstallScriptPath) {
                Write-Host "     [Post-Install Script: Started]" -ForegroundColor DarkGreen
            
                Write-Debug "Running post-install script for $toolName..."
                try {
                    & $postInstallScriptPath $Usern
                    Write-Host "     [Post-Install Script: OK]" -ForegroundColor DarkGreen
                } catch {
                    Write-Host "     [Post-Install Script: Failed]" -ForegroundColor DarkRed
                    Write-Debug "Failed to execute post-install script $postInstallScriptPath : $_"
                }              
            } else {
                Write-Debug "No post-install script found for $toolName."
                Write-Host "     [Post-Install Script: Skipped/N.A.]" -ForegroundColor DarkGreen
            }
        }
        # Fortschrittsanzeige aktualisieren
        #Write-Host ""
        if ($installerConfig.Name -ne "Manual.conf") {
            $counter++
        }
    }
    ##############################
    ### Manual Install Section ###
    ##############################

    Write-Host ""
    Write-Host "#####################"
    Write-Host "Manual Install Tools" -ForegroundColor Green
    Write-Host "#####################"
    Write-Host ""
    # Execute all collected manual install commands
    for ($i = 0; $i -lt $manualInstallCommands.Count; $i++) {
        $commandLine = $manualInstallCommands[$i]
        $toolName = $manualInstallToolName[$i]
        Write-Host "" #Neue Zeile für bessere Lesbarkeit

        $percentComplete = ($counter / $totalLines) * 100
        
        Write-Debug "Installing Manual $commandLine"
        #$filename = ($commandLine -split '\s+')[-1]

        Write-Progress -PercentComplete $percentComplete -Status "[$counter/$totalLines]" -Activity "Installing $toolName (Manual)"

        Write-Debug "Commandlinevar: $commandLine"
        Write-Debug "Toolname var: $toolName"
        # Start a new job for each manual installation
        Write-Host "----- Installing $toolName -----" -ForegroundColor Green
        install-manual $commandLine $toolName
        $counter++
        #Write-Host "     [Installation OK: $toolName]" -ForegroundColor DarkGreen
    }

    # Maybe later in the loop above
    ##############
    Write-Host ""
    Write-Host "----- Manual Install Post Install Scripts -----" -ForegroundColor Green
    foreach ($toolName in $manualInstallToolName) {
        Write-Host "|-- $toolName" -ForegroundColor DarkGreen
            # Überprüfen und Ausführen eines Skripts im Ordner "$pp_script_folder"
        $postInstallScriptPath = "$pp_script_folder\$toolName.ps1"
            #Write-Host "Post-Install-Script: $postInstallScriptPath"
            if (Test-Path $postInstallScriptPath) {
                Write-Host "|--- Post-Install-Script Started" -ForegroundColor DarkGreen
                Write-Debug "Running post-install script for $toolName..."
                try {
                    & $postInstallScriptPath $Usern #*>> $LOGFILE2
                    Write-Host "|--- Post-Install-Script Finished Successfully" -ForegroundColor DarkGreen
                } catch {
                    Write-Host "|--- Post-Install-Script FAILED" -ForegroundColor Red
                    Write-Debug "Failed to execute post-install script $postInstallScriptPath : $_" 
                }
            } else {
                Write-Debug "No post-install script found for $toolName."
                Write-Host " SKIPPED/N.A.]"
            }
    }

    Write-Progress -PercentComplete 100 -Status "[$totalLines/$totalLines]" -Activity "All Tools Installed"
    Write-Host ""
    Write-Host "#############################################################################################"
    Write-Host "#############################################################################################"
    Write-Host "#############################################################################################"
    Write-Host ""
    Read-Host -Prompt "Press [Enter] if every installer windows that were spawned were closed (Installed)"

    Write-Host ""
    Write-Host "######## Post Processing ########" -ForegroundColor Green
    Write-Host ""
    post-processing $Usern
    
    Write-Host ""
    Write-Host "######## Copy Documents and Templates ########" -ForegroundColor Green
    Write-Host ""
    copy-documents $Usern

    $currentLocation = (Get-Location).Path
    #if ($currentLocation -ne "C:\DFIR\_dfir-installer\dfir-installer-main") {
    #    # Also copy the flag file to C:\DFIR\_dfir-installer
    #    $flagCopyTarget = "C:\DFIR\_dfir-installer\DFIR-Installer.flag"
    #    Copy-Item -Path $FLAG_PATH -Destination $flagCopyTarget -Force
    #}

    # Beispiel für den Wert von $config
    # Aufruf der Funktion und Ergebnis speichern
    $shouldUpdate = AskForUpdate $config

    #update-zimmermann DEPRECTATED and transfered to Post-Installation Fixes

    # Weiterer Code, um das Update basierend auf $shouldUpdate durchzuführen
    if ($shouldUpdate) {
        Write-Host "The Update will be started now."
        post-install-fixes
    } else {
        Write-Host "No Update Needed."
    }

    # Set Path Var
    path-var-config-import
    
    

    #####################
    #### TODO WSL #######
    #####################

    Write-Host ""
    ### Logging Ended
    # Message to be displayed on screen
    Write-Host "Detailed Logging was written to $logFilePath."

    # Stop logging
    Stop-Transcript

    Write-Host "The Script will start some tasks now to finish the setup."
}

# Aufruf der Main-Methode am Ende des Skripts
Write-Host @"
____________ ___________     _____          _        _ _           
|  _  \  ___|_   _| ___ \   |_   _|        | |      | | |          
| | | | |_    | | | |_/ /_____| | _ __  ___| |_ __ _| | | ___ _ __ 
| | | |  _|   | | |    /______| || '_ \/ __| __/ _` | | |/ _ \ '__|
| |/ /| |    _| |_| |\ \     _| || | | \__ \ || (_| | | |  __/ |   
|___/ \_|    \___/\_| \_|    \___/_| |_|___/\__\__,_|_|_|\___|_|   
                                                                   
"@  -ForegroundColor Green

Main



